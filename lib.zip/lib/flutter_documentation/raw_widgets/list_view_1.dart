import 'package:flutter/material.dart';

class ListView_1 extends StatelessWidget {
  const ListView_1({super.key});




  @override
  Widget build(BuildContext context) {
   return ListView( ///body
     scrollDirection: Axis.vertical,
     children: const [
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
       Text("masterShanto",style: TextStyle(color: Colors.blue,backgroundColor: Colors.white,fontSize: 50)),
     ],
   );
  }
}