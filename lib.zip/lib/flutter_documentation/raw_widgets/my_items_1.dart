
class MyItems_1{
  var MyImages=[
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech1"},
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech2"},
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech3"},
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech4"},
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech5"},
    {"img":"https://dnc.techtunes.io/tDrive/tuner/2010/06/techtunes_8be74aae67444f7a7fe252c1cf1d7692-368x207.png","title":"tech6"},
  ];

}