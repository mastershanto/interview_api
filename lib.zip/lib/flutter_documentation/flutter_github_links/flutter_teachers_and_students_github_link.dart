///todo: ## Rabbil Vai: https://github.com/rupomsoft/Flutter-Batch
///todo: ## Rabbil vai sourseCode: https://github.com/rupomsoft/Flutter-Batch/tree/main/Flutter/Source%20Code

///todo: ## Rafat vai: https://github.com/RafatMeraz/ostad_flutter_batch_four

///todo: ## shakibul: https://github.com/ShakibulDeveloper/Mobile-Banking-App
///todo: # arafat: https://github.com/csearafat01/module_6/
///todo: # Labib: https://github.com/Labibzaman/
///todo: # Fahim: https://github.com/Zihadul-Islam-Fahim
///todo: # Shahadat: https://github.com/Shahadat102099
///todo: # Rabby: https://github.com/Rabby3075/NewsFeed
///todo: # Rayhan: https://github.com/ai-rayhan/ostad_module_06_assignment

///todo: ## Tanvir Mahtab Toha: https://github.com/devtanvirmahtab


